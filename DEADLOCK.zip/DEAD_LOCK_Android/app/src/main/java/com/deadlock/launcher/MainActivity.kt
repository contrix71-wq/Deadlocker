package com.deadlock.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.media.MediaPlayer

class MainActivity : Activity() {
    private val red = Color.rgb(255, 36, 61)
    private var entered = ""
    private var failures = 0
    private lateinit var pinDots: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showPin()
    }

    // Keep Android navigation available: the owner can always leave or restore the system launcher.
    private fun fullscreen() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    private fun text(value: String, size: Float, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun showPin() {
        fullscreen()
        entered = ""
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.BLACK)
        }
        root.addView(text("DEAD LOCK", 32f, red))
        root.addView(text("ВВЕДИТЕ PIN-КОД", 14f), LinearLayout.LayoutParams(-1, 60))
        pinDots = text("••••", 28f, red)
        root.addView(pinDots, LinearLayout.LayoutParams(-1, 58))
        val grid = GridLayout(this).apply { columnCount = 3 }
        for (n in 1..9) addDigit(grid, n.toString())
        addDigit(grid, "⌫")
        addDigit(grid, "0")
        addDigit(grid, "✓")
        root.addView(grid, LinearLayout.LayoutParams(-1, 340))
        setContentView(root)
    }

    private fun addDigit(grid: GridLayout, value: String) {
        val key = text(value, 25f, red)
        key.setOnClickListener {
            when (value) {
                "⌫" -> { entered = entered.dropLast(1); pinDots.text = "•".repeat(entered.length).ifEmpty { "••••" } }
                "✓" -> verifyPin()
                else -> if (entered.length < 4) {
                    entered += value
                    pinDots.text = "•".repeat(entered.length)
                    if (entered.length == 4) verifyPin()
                }
            }
        }
        grid.addView(key, GridLayout.LayoutParams().apply {
            width = 0; height = 85
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        })
    }

    private fun verifyPin() {
        if (entered == "4928") {
            playIntro()
        } else {
            entered = ""
            pinDots.text = "НЕВЕРНЫЙ КОД"
            failures++
            if (failures >= 2) {
                AlertDialog.Builder(this)
                    .setTitle("Помилование")
                    .setMessage("Можно вернуться к штатному экрану Android.")
                    .setPositiveButton("Открыть выбор лаунчера") { _, _ -> openHomeSettings() }
                    .setNegativeButton("Повторить", null)
                    .show()
            }
        }
    }

    private fun playIntro() {
        fullscreen()
        val video = VideoView(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(video)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.intro}"))
        video.setOnCompletionListener { showPhoto() }
        video.setOnErrorListener { _, _, _ -> showPhoto(); true }
        video.start()
    }

    private fun showPhoto() {
        fullscreen()
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.home_photo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        frame.addView(photo, FrameLayout.LayoutParams(-1, -1))
        val message = TextView(this).apply {
            text = ""
            textSize = 17f
            setTextColor(red)
            typeface = Typeface.create("monospace", Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
            setPadding(18, 12, 18, 12)
        }
        val lp = FrameLayout.LayoutParams(-1, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        frame.addView(message, lp)
        setContentView(frame)
        val lines = listOf(
            "THE BEST GHOSTS",
            "DEAD LOCK // TEST SIMULATION",
            "SYSTEM MESSAGE: DEMO MODE"
        )
        val full = lines.joinToString("\n")
        val handler = android.os.Handler(mainLooper)
        var index = 0
        val ticker = object : Runnable {
            override fun run() {
                if (index <= full.length) {
                    message.text = full.take(index) + if (index % 2 == 0) "▌" else ""
                    index++
                    handler.postDelayed(this, 55)
                }
            }
        }
        handler.post(ticker)
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent("android.settings.HOME_SETTINGS"))
        } catch (_: Exception) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }
    }

    override fun onBackPressed() {
        // Normal Android back navigation remains available.
        super.onBackPressed()
    }
}
